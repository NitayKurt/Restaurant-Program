from enum import Enum


# Enum class for Main meal Prices
class SideDishPrices(Enum):
    three_cheese_asparagus_gratin = 30
    corn_pudding = 35
    chips = 30

