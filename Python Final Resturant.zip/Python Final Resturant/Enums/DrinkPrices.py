from enum import Enum


# Enum class for Main meal Prices
class DrinkPrices(Enum):
    water = 8
    Coca_Cola = 15
    FuzeTea = 10
    Orange_Juice = 12


