from enum import Enum


# Enum class for Main meal Prices
class MainMealPrices(Enum):
    soup = 40
    Shakshuka = 45
    Fish_and_chips = 60
    Lazania = 50


