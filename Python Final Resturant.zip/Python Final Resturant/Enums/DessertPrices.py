from enum import Enum


# Enum class for Main meal Prices
class DessertPrices(Enum):
    chocolate_chip_cookies = 30
    apple_pie = 28
    cheese_cake = 30

