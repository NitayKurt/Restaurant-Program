from enum import Enum


# Enum class for Main meal Prices
class StartPrices(Enum):
    Scramble_egg_with_bread = 45
    Sandwich_with_Tuna = 20
    Salad_with_vegetables = 35
    Hot_bread_with_butter = 20