from RestaurantLogic.Restaurant import Restaurant
#
if __name__ == '__main__':
    Restaurant().open_restaurant()
