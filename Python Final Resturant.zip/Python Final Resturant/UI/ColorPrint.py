def print_cyan(skk): print("\033[96m {}\033[00m" .format(skk))
def print_cyan_end(skk): print("\033[96m {}\033[00m" .format(skk), end="")


def pr_red(skk): print("\033[91m {}\033[00m" .format(skk))
def pr_green(skk): print("\033[92m {}\033[00m" .format(skk))
def pr_yellow(skk): print("\033[93m {}\033[00m" .format(skk))
def pr_light_purple(skk): print("\033[94m {}\033[00m" .format(skk))
def pr_purple(skk): print("\033[95m {}\033[00m" .format(skk))
def pr_light_gray(skk): print("\033[97m {}\033[00m" .format(skk))
def pr_black(skk): print("\033[98m {}\033[00m" .format(skk))